s1=input()
s2=""
for i in range(len(s1)):
    s2=s2+s1[len(s1)-(i+1)]
print(s2)